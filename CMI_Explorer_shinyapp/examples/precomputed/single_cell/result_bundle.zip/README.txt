CMI Explorer result bundle
==========================

Module: single_cell   Version: 2.0.0   Created: 2026-10-19 15:26 UTC

provenance.json   input checksum, parameters, package versions and the SHA-256 of every model asset used
summary.json      the numbers shown in the interface
run.log           the steps the worker took
figures/          each figure as SVG (editable text), PDF (vector, embedded fonts) and PNG (600 dpi)
figures/panels/   the same figures without title, subtitle and caption, for assembling your own figures
figures/legends.txt  title, subtitle and caption text of every figure
qc/               audit and intermediate tables

cells.csv columns
  CMI          clonal malignancy index of the cell (0-1; a model score, not a probability)
  state        CMI grade: Below threshold (CMI < 0.97551), Mal-1 (to 0.98926), Mal-2 (to 0.99620) or Mal-3 (above)
  malignant    CMI at or above the malignancy threshold (0.97551)
  Ig_score, cnv_score, mtp_score, diff_score, prol_score  the five inputs of the CMI
  n_counts     UMIs per cell
  b_markers_detected  any UMI of CD19, MS4A1, CD79A, CD79B or PAX5 (upload check only)
  non_b_markers_dominant  2 or more UMIs of CD3E, CD3D, LYZ, CD14, NKG7, HBB or PPBP, and more than of the B-cell markers (upload check only)

Research use only. Not for diagnosis or treatment decisions.
