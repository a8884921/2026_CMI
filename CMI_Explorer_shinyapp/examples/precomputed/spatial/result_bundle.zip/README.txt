CMI Explorer result bundle
==========================

Module: spatial   Version: 2.0.0   Created: 2026-10-19 15:26 UTC

provenance.json   input checksum, parameters, package versions and the SHA-256 of every model asset used
summary.json      the numbers shown in the interface
run.log           the steps the worker took
figures/          each figure as SVG (editable text), PDF (vector, embedded fonts) and PNG (600 dpi)
figures/panels/   the same figures without title, subtitle and caption, for assembling your own figures
figures/legends.txt  title, subtitle and caption text of every figure
qc/               audit and intermediate tables

spots.csv: CMI grade (Mal-1, Mal-2, Mal-3 or Non-malignant), class of highest weight, malignant load and normalized weights per spot
grades.csv: spots per grade, share of spots and share of the summed Mal-1/2/3 weight

Research use only. Not for diagnosis or treatment decisions.
