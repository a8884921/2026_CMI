CMI Explorer result bundle
==========================

Module: bulk   Version: 2.0.0   Created: 2026-10-19 15:26 UTC

provenance.json   input checksum, parameters, package versions and the SHA-256 of every model asset used
summary.json      the numbers shown in the interface
run.log           the steps the worker took
figures/          each figure as SVG (editable text), PDF (vector, embedded fonts) and PNG (600 dpi)
figures/panels/   the same figures without title, subtitle and caption, for assembling your own figures
figures/legends.txt  title, subtitle and caption text of every figure
qc/               audit and intermediate tables

samples.csv columns
  riskscore    CMI-riskscore of the sample (higher = higher predicted risk)
  cmi_group    CMI-high above the median of this cohort, otherwise CMI-low
  pair_coverage  share of the 100 REO gene pairs computable from this matrix

Research use only. Not for diagnosis or treatment decisions.
