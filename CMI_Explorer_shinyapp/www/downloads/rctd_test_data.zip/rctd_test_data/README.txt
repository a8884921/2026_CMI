Test data for rctd_mal_states.R (CMI Explorer 2.0.0)

A synthetic fixture: 300 reference cells (150 malignant, with CMI values in Mal-1, Mal-2 and Mal-3,
and 50 each of CD4_T, Macrophage and Stromal), 2,400 genes, and a section of 36 spots. It is the RCTD
test fixture of the original application (v1.2.0); the values are not biology. It has no class of
normal B cells, so the script prints a warning about that.

  reference_counts/        10x folder (matrix.mtx.gz, features.tsv.gz, barcodes.tsv.gz)
  reference_labels.csv     cell, cell_type (Malignant or the class name), CMI
  section/outs/            Space Ranger-style folder: filtered_feature_bc_matrix/ and spatial/tissue_positions.csv
  expected_weights.csv     the weights v1.2.0 computed for this section

Run (about a minute):
  Rscript rctd_mal_states.R --ref-counts rctd_test_data/reference_counts \
      --ref-labels rctd_test_data/reference_labels.csv --spatial rctd_test_data/section/outs \
      --output test_weights.csv

Compare (in R):
  a <- read.csv("test_weights.csv", check.names = FALSE); e <- read.csv("rctd_test_data/expected_weights.csv", check.names = FALSE)
  max(abs(as.matrix(a[, -(1:3)]) - as.matrix(e[match(a$spot_id, e$spot_id), names(a)[-(1:3)]])))   # about 1e-13

test_weights.csv can then be uploaded to Spatial states (choose "Other or unknown" as spot technology).
